#include "Program.h"
void Program::display() {
	cout <<"name: "<< m_title << " type: " << getType() << " duration: " << m_duration << "min"<<endl;
}




